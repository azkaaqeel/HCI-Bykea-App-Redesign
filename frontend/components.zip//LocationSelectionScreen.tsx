import { ArrowLeft, MapPin, Home, Briefcase, Plus, Search } from './ui/icons';
import { useState } from 'react';

interface LocationSelectionScreenProps {
  onBack: () => void;
  onSelectLocation: (location: string) => void;
  type: 'pickup' | 'dropoff';
}

const savedAddresses = [
  { icon: Home, label: 'Home', address: 'House 23, F-7/2, Islamabad' },
  { icon: Briefcase, label: 'Work', address: 'Blue Area, G-9, Islamabad' },
];

const recentLocations = [
  'FAST University, Karachi',
  'Centaurus Mall, Islamabad',
  'Jinnah Super Market, Karachi',
];

const areas = [
  'Karachi',
  'Surjani Town',
  'New Karachi',
  'North Nazimabad',
  'FB Area',
  'Gulshan-e-Maymar',
  'Sohrab Goth',
  'Scheme 33',
  'Gulistan-e-Johar',
  'Malir & Airport',
  'Landhi',
  'Shah Faisal Town',
  'Korangi',
  'PAF',
  'Mehmoodabad',
  'Qayyumabad',
];

export function LocationSelectionScreen({ onBack, onSelectLocation, type }: LocationSelectionScreenProps) {
  const [activeTab, setActiveTab] = useState<'recent' | 'map' | 'area'>('area');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredAreas = areas.filter(area =>
    area.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredRecent = recentLocations.filter(location =>
    location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="relative h-screen w-full max-w-md mx-auto bg-white overflow-hidden flex flex-col">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <div className="text-black">9:55</div>
        <div className="flex items-center gap-1">
          <div className="text-black">56</div>
        </div>
      </div>

      {/* Header with Search */}
      <div className="px-4 py-3">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={onBack} className="p-2 -ml-2">
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </button>
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Pick Up"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-[#00D47C] rounded-full focus:outline-none text-gray-900 placeholder:text-gray-500"
            />
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 bg-gray-100 rounded-full p-1">
          <button
            onClick={() => setActiveTab('recent')}
            className={`flex-1 py-2 px-4 rounded-full transition-all ${
              activeTab === 'recent'
                ? 'bg-white text-gray-800 shadow-sm'
                : 'text-gray-500'
            }`}
          >
            Recent
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`flex-1 py-2 px-4 rounded-full transition-all ${
              activeTab === 'map'
                ? 'bg-white text-gray-800 shadow-sm'
                : 'text-gray-500'
            }`}
          >
            Map
          </button>
          <button
            onClick={() => setActiveTab('area')}
            className={`flex-1 py-2 px-4 rounded-full transition-all ${
              activeTab === 'area'
                ? 'bg-[#00D47C] text-white shadow-sm'
                : 'text-gray-500'
            }`}
          >
            Area
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === 'recent' && (
          <div className="px-4">
            {/* Use Current Location */}
            <button className="w-full bg-[#00D47C] text-white rounded-xl py-4 px-6 flex items-center justify-center gap-3 mb-6 shadow-lg">
              <MapPin className="w-6 h-6" />
              <span>Use Current Location</span>
            </button>

            {/* Saved Addresses */}
            <div className="mb-6">
              <h3 className="text-gray-600 mb-3">Saved Addresses</h3>
              <div className="space-y-1">
                {savedAddresses.map((address, index) => {
                  const Icon = address.icon;
                  return (
                    <button
                      key={index}
                      onClick={() => onSelectLocation(address.address)}
                      className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors text-left"
                    >
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-gray-600" />
                      </div>
                      <div className="flex-1">
                        <p className="text-black">{address.label}</p>
                        <p className="text-sm text-gray-500">{address.address}</p>
                      </div>
                    </button>
                  );
                })}
                <button className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors text-left">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <Plus className="w-5 h-5 text-[#00D47C]" />
                  </div>
                  <p className="text-[#00D47C]">Add New Address</p>
                </button>
              </div>
            </div>

            {/* Recent Locations */}
            <div>
              <h3 className="text-gray-600 mb-3">Recent Locations</h3>
              <div className="space-y-1">
                {filteredRecent.map((location, index) => (
                  <button
                    key={index}
                    onClick={() => onSelectLocation(location)}
                    className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors text-left"
                  >
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-black">{location}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'map' && (
          <div className="h-full bg-gray-100 flex items-center justify-center">
            <p className="text-gray-500">Map view coming soon</p>
          </div>
        )}

        {activeTab === 'area' && (
          <div className="px-4">
            <h3 className="text-gray-600 mb-3">Karachi</h3>
            <div className="space-y-1 pb-6">
              {/* Current Location as first option */}
              <button
                onClick={() => onSelectLocation('Current Location')}
                className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors text-left"
              >
                <div className="w-10 h-10 bg-[#00D47C] rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <p className="text-black">Current Location</p>
              </button>

              {filteredAreas.map((area, index) => (
                <button
                  key={index}
                  onClick={() => onSelectLocation(area)}
                  className="w-full text-left p-4 hover:bg-gray-50 rounded-xl transition-colors text-black"
                >
                  {area}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Home Indicator */}
      <div className="pb-4 flex justify-center">
        <div className="w-32 h-1 bg-black rounded-full"></div>
      </div>
    </div>
  );
}