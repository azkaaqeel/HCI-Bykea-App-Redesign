import { MapPin } from './ui/icons';
import { useState, useEffect } from 'react';

export function MapView() {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });

  // Map centered on Karachi coordinates: 24.8607, 67.0011
  // Using zoom level 14
  const centerLat = 24.8607;
  const centerLon = 67.0011;
  const zoom = 14;

  // Calculate tile coordinates for static map display
  const tileSize = 256;
  const tiles = [
    { x: -1, y: -1 },
    { x: 0, y: -1 },
    { x: 1, y: -1 },
    { x: -1, y: 0 },
    { x: 0, y: 0 },
    { x: 1, y: 0 },
    { x: -1, y: 1 },
    { x: 0, y: 1 },
    { x: 1, y: 1 },
  ];

  // Convert lat/lon to tile coordinates
  const lat2tile = (lat: number, zoom: number) => {
    return Math.floor(((1 - Math.log(Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)) / Math.PI) / 2) * Math.pow(2, zoom));
  };

  const lon2tile = (lon: number, zoom: number) => {
    return Math.floor(((lon + 180) / 360) * Math.pow(2, zoom));
  };

  const centerTileX = lon2tile(centerLon, zoom);
  const centerTileY = lat2tile(centerLat, zoom);

  return (
    <>
      <div className="absolute inset-0 z-0 bg-gray-100 overflow-hidden">
        {/* Map tiles grid */}
        <div
          className="absolute inset-0"
          style={{
            transform: `translate(${position.x}px, ${position.y}px)`,
            cursor: isDragging ? 'grabbing' : 'grab',
          }}
          onMouseDown={(e) => {
            setIsDragging(true);
            setStartPos({ x: e.clientX - position.x, y: e.clientY - position.y });
          }}
          onMouseMove={(e) => {
            if (isDragging) {
              setPosition({ x: e.clientX - startPos.x, y: e.clientY - startPos.y });
            }
          }}
          onMouseUp={() => setIsDragging(false)}
          onMouseLeave={() => setIsDragging(false)}
          onTouchStart={(e) => {
            setIsDragging(true);
            const touch = e.touches[0];
            setStartPos({ x: touch.clientX - position.x, y: touch.clientY - position.y });
          }}
          onTouchMove={(e) => {
            if (isDragging) {
              const touch = e.touches[0];
              setPosition({ x: touch.clientX - startPos.x, y: touch.clientY - startPos.y });
            }
          }}
          onTouchEnd={() => setIsDragging(false)}
        >
          {tiles.map((tile) => (
            <img
              key={`${tile.x}-${tile.y}`}
              src={`https://tile.openstreetmap.org/${zoom}/${centerTileX + tile.x}/${centerTileY + tile.y}.png`}
              alt=""
              className="absolute pointer-events-none select-none"
              style={{
                left: `calc(50% + ${tile.x * tileSize}px - ${tileSize / 2}px)`,
                top: `calc(50% + ${tile.y * tileSize}px - ${tileSize / 2}px)`,
                width: `${tileSize}px`,
                height: `${tileSize}px`,
              }}
              draggable={false}
            />
          ))}
        </div>
      </div>

      {/* User location marker */}
      <div className="absolute top-[38%] left-[55%] -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none">
        <div className="relative">
          <div className="absolute -inset-2 bg-blue-400 rounded-full opacity-30 animate-ping"></div>
          <div className="relative w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg"></div>
        </div>
      </div>
      
      {/* Green marker */}
      <div className="absolute top-[35%] left-[52%] z-10 pointer-events-none">
        <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
          <div className="w-3 h-3 bg-white rounded-full"></div>
        </div>
      </div>

      {/* Business marker overlay */}
      <div className="absolute top-[32%] left-[20%] z-10 pointer-events-none">
        <div className="flex flex-col items-center">
          <div className="bg-white px-2 py-1 rounded shadow-md mb-1">
            <p className="text-xs text-blue-600">WASAY TRADER</p>
            <p className="text-xs text-gray-600">Trading card store</p>
          </div>
          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center shadow-lg">
            <MapPin className="w-3 h-3 text-white fill-white" />
          </div>
        </div>
      </div>
    </>
  );
}