import { Menu, MapPin, Search, Heart, Clock } from './ui/icons';
import { BottomNav } from './BottomNav';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ShopsScreenProps {
  onBack: () => void;
  onTabChange?: (tab: string) => void;
  onShopClick?: () => void;
}

export function ShopsScreen({ onBack, onTabChange, onShopClick }: ShopsScreenProps) {
  const categories = [
    { name: 'Groceries', color: 'bg-green-100', icon: '🛒' },
    { name: 'Pharmacy', color: 'bg-red-100', icon: '💊' },
    { name: 'Electronics', color: 'bg-blue-100', icon: '📱' },
    { name: 'Bakery', color: 'bg-yellow-100', icon: '🥖' },
    { name: 'Fresh Bazaar', color: 'bg-orange-100', icon: '🥬' },
  ];

  const popularShops = [
    {
      id: 1,
      name: 'Al-Fatah',
      category: 'Groceries',
      deliveryTime: '15–25 min',
      badge: 'Fast Delivery',
      badgeColor: 'bg-[#00D47C]',
    },
    {
      id: 2,
      name: 'Agha Khan Pharmacy',
      category: 'Pharmacy',
      deliveryTime: '20–30 min',
      badge: 'Discount Available',
      badgeColor: 'bg-orange-500',
    },
    {
      id: 3,
      name: 'Metro Cash & Carry',
      category: 'Groceries',
      deliveryTime: '25–35 min',
      badge: 'Popular',
      badgeColor: 'bg-blue-500',
    },
    {
      id: 4,
      name: 'Imtiaz Super Market',
      category: 'Groceries',
      deliveryTime: '20–30 min',
      badge: 'Fast Delivery',
      badgeColor: 'bg-[#00D47C]',
    },
  ];

  const previousOrders = [
    {
      id: 1,
      shopName: 'Al-Fatah',
      items: 'Groceries',
      amount: 'Rs 1,250',
    },
    {
      id: 2,
      shopName: 'Metro',
      items: 'Fresh Items',
      amount: 'Rs 850',
    },
    {
      id: 3,
      shopName: 'Imtiaz',
      items: 'Snacks',
      amount: 'Rs 620',
    },
  ];

  return (
    <div className="relative h-screen w-full max-w-md mx-auto bg-white overflow-hidden">
      {/* Status Bar */}
      <div className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-4 pt-2 pb-1 bg-white">
        <div className="text-black">9:55</div>
        <div className="text-black">24%</div>
      </div>

      {/* Top Header */}
      <div className="absolute top-8 left-0 right-0 z-40 flex items-center justify-between px-4 bg-white pb-2">
        <div className="flex items-center gap-2 bg-gray-100 rounded-full px-3 py-1">
          <MapPin className="w-4 h-4 text-gray-600" />
          <span className="text-xs text-gray-800">Jamia Darul Khair</span>
        </div>
        <div className="flex items-center gap-3">
          <button className="bg-gray-100 rounded-full p-2">
            <Heart className="w-4 h-4 text-gray-600" />
          </button>
          <button className="flex items-center gap-1 bg-gray-100 rounded-full px-3 py-1">
            <Clock className="w-3 h-3 text-gray-600" />
            <span className="text-xs text-gray-600">Now</span>
          </button>
        </div>
      </div>

      {/* Menu Button */}
      <button 
        onClick={onBack}
        className="absolute top-20 left-4 z-40 bg-white rounded-lg p-3 shadow-lg"
      >
        <Menu className="w-6 h-6 text-gray-700" />
      </button>

      {/* Main Content - Scrollable */}
      <div className="h-full overflow-y-auto pt-32 pb-40">
        <div className="px-4">
          {/* Title */}
          <h1 className="mb-4">Nearby Shops</h1>

          {/* Search Bar */}
          <div className="flex items-center gap-2 bg-gray-100 rounded-2xl px-4 py-3 mb-6">
            <Search className="w-5 h-5 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search for shops or products"
              className="flex-1 bg-transparent border-none outline-none text-gray-800 placeholder:text-gray-400"
            />
            <button className="bg-white rounded-lg p-2 shadow-sm">
              <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
            </button>
          </div>

          {/* Categories Section */}
          <div className="mb-6">
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              {categories.map((category, index) => (
                <button 
                  key={index}
                  className={`flex-shrink-0 flex flex-col items-center gap-2 ${category.color} rounded-2xl px-6 py-4 min-w-[100px]`}
                >
                  <span className="text-2xl">{category.icon}</span>
                  <span className="text-xs text-gray-700">{category.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Popular Shops Section */}
          <div className="mb-6">
            <h2 className="mb-3">Popular Near You</h2>
            <div className="grid grid-cols-2 gap-3">
              {popularShops.map((shop) => (
                <button 
                  key={shop.id}
                  onClick={onShopClick}
                  className="bg-white border border-gray-200 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left"
                >
                  <div className="bg-gray-100 rounded-xl h-24 mb-3 flex items-center justify-center">
                    <span className="text-3xl">🏪</span>
                  </div>
                  <h3 className="mb-1 text-gray-800">{shop.name}</h3>
                  <p className="text-xs text-gray-500 mb-2">{shop.category}</p>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-gray-400" />
                      <span className="text-xs text-gray-600">{shop.deliveryTime}</span>
                    </div>
                  </div>
                  <div className={`${shop.badgeColor} text-white rounded-full px-2 py-1 text-xs inline-block`}>
                    {shop.badge}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Promotional Banner */}
          <div className="mb-6 bg-gradient-to-r from-[#00D47C] to-[#00b869] rounded-2xl p-6 text-white shadow-lg">
            <h2 className="text-white mb-2">30% Off on First Order! 🎉</h2>
            <p className="text-sm text-white/90 mb-4">Use code: FIRSTORDER at checkout</p>
            <button className="bg-white text-[#00D47C] px-6 py-2 rounded-full">
              Shop Now
            </button>
          </div>

          {/* Previous Orders Section */}
          <div className="mb-6">
            <h2 className="mb-3">Order Again</h2>
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              {previousOrders.map((order) => (
                <div 
                  key={order.id}
                  className="flex-shrink-0 bg-white border border-gray-200 rounded-2xl p-4 min-w-[160px] shadow-sm"
                >
                  <div className="bg-gray-100 rounded-xl h-20 mb-3 flex items-center justify-center">
                    <span className="text-2xl">🛍️</span>
                  </div>
                  <h3 className="mb-1 text-gray-800">{order.shopName}</h3>
                  <p className="text-xs text-gray-500 mb-2">{order.items}</p>
                  <p className="text-sm text-[#00D47C]">{order.amount}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav activeTab="shops" onTabChange={onTabChange} />

      {/* Home Indicator */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-black rounded-full"></div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}