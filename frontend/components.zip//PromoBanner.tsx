import { Bell } from './ui/icons';

export function PromoBanner() {
  return (
    <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl p-4 shadow-lg flex items-center gap-3">
      <div className="bg-yellow-400 rounded-full p-2 flex-shrink-0">
        <Bell className="w-6 h-6 text-purple-900" />
      </div>
      <p className="text-white flex-1">
        <span>Azka Aqeel, Get a </span>
        <span>30% DISCOUNT</span>
        <span> on Your Next Car Ride. </span>
        <span>Book Now!</span>
      </p>
    </div>
  );
}